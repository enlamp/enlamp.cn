<div style="clear: both;"></div>
</div> <!-- // wrapper -->

	<div id="footer">
		<p>
		    <?php echo prologue_poweredby_link(); ?>
		    <?php printf(__('P2 theme by %s.', 'p2'), '<a href="http://automattic.com/">Automattic</a>'); ?>
		</p>
	</div>
	
<?php wp_footer(); ?>

</body>
</html>